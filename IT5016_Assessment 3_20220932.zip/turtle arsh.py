import turtle
import random

# Create a Turtle object
t = turtle.Turtle()

# Set the turtle speed and color
t.speed(0)
turtle.colormode(255)

# Define a function to draw a random shape with changing colors
def random_shape(length, color):
    t.pencolor(color)
    sides = random.randint(3, 8)
    angle = 360 / sides
    for i in range(sides):
        t.forward(length)
        t.right(angle)

# Draw multiple random shapes with varying parameters
for i in range(100):
    x = random.randint(-300, 300)
    y = random.randint(-300, 300)
    length = random.randint(20, 100)
    color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    t.penup()
    t.goto(x, y)
    t.pendown()
    random_shape(length, color)

# Hide the turtle
t.hideturtle()

# Wait for the user to close the window
turtle.done()